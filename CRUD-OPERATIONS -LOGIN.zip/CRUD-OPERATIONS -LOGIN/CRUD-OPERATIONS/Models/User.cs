﻿using System;
using System.Collections.Generic;

namespace CRUD_OPERATIONS.Models
{
    public partial class User
    {
        public User()
        {
            Employees = new HashSet<Employee>();
        }

        public int UserId { get; set; }
        public string UserName { get; set; } = null!;
        public string UserPassword { get; set; } = null!;
        public string?  Role { get; set; } = null!;

        public virtual ICollection<Employee> ?Employees { get; set; }
    }
}

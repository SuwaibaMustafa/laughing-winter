﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CRUD_OPERATIONS.Models
{
    public partial class Employee
    {
        public int EmployeeId { get; set; }

        [RegularExpression("^[a-zA-Z]+( [a-zA-Z]+)?$", ErrorMessage = "Only alphabets are allowed.")]
        public string Name { get; set; } = null!;

        [RegularExpression("^[a-zA-Z]+@gmail\\.com$", ErrorMessage = "Invalid email address. Please enter a valid Gmail address.")]
        public string Email { get; set; } = null!;

        [RegularExpression("^[a-zA-Z]+( [a-zA-Z]+)?$", ErrorMessage = "Only alphabets are allowed.")]
        public string Position { get; set; } = null!;
        public int DepartmentId { get; set; }
        public int? LoginId { get; set; }

        public virtual Department? Department { get; set; } = null!;
        public virtual User? Login { get; set; }
    }
}

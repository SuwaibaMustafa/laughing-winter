﻿using CRUD_OPERATIONS.Models;
using Microsoft.AspNetCore.Mvc;

namespace CRUD_OPERATIONS.Controllers
{
    public class AccountController : Controller
    {
        private EmployeeDBContext loginDatabase=new EmployeeDBContext();
        public IActionResult Index()
        {
            return View();
        }
        // Get Action
        public IActionResult Login()
        {

            if (HttpContext.Session.GetString("UserName") == null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        //Post Action
        [HttpPost]
        public ActionResult Login(User u)
        {
            if (HttpContext.Session.GetString("UserName") == null)
            {

                if (ModelState.IsValid)
                {
                    using (EmployeeDBContext db = new EmployeeDBContext())
                    {
                        var obj = db.Users.Where(a => a.UserName.Equals(u.UserName) && a.UserPassword.Equals(u.UserPassword)).FirstOrDefault();
                        if (obj!=null) {
                            TempData["UserId"] = (int)obj.UserId;
                        }
                        if (obj != null)
                        {
                            if (obj.Role == "user") {
                                HttpContext.Session.SetString("UserName", obj.UserName.ToString());
                                return RedirectToAction("Index", "Employees");
                            }
                            else if (obj.Role == "admin") {
                                HttpContext.Session.SetString("UserName", obj.UserName.ToString());
                                return RedirectToAction("Index", "Departments");
                            }
                        }
                    }
                }
            }
            else
            {

                return RedirectToAction("Login");
            }
            return View();
        }

        //Displaying
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(User u)
        {
            if (ModelState.IsValid)
            {
                u.Role = "user";
                bool isDuplicate = loginDatabase.Users.Any(e => e.UserName == u.UserName);
                if (isDuplicate)
                {
                    ViewBag.message = "User already registered";
                    return View(u);
                }
                loginDatabase.Users.Add(u);
                loginDatabase.SaveChanges();
                TempData["ToastrMessage"] = "Registered successfully! ";
                TempData.Keep();
                return RedirectToAction("Login");
            }
            return View(u);
        }

        public ActionResult Logout()
        {

            HttpContext.Session.Clear();
            HttpContext.Session.Remove("UserName");

            return RedirectToAction("Login");
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;

namespace CRUD_OPERATIONS.Controllers
{
    public class ErrorController : Controller
    {
        public ActionResult PageNotFound() 
        { 
            return View();
        }
    }
}

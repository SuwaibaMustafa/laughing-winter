﻿using CRUD_OPERATIONS.Interfaces;
using CRUD_OPERATIONS.Models;
using Microsoft.EntityFrameworkCore;

namespace CRUD_OPERATIONS.Repositories
{
    public class GenericRepository<T>: IGenericRepository<T> where T : class

    {
        protected readonly EmployeeDBContext _context;
        protected readonly DbSet<T> _dbSet;

        public GenericRepository(EmployeeDBContext context)
        {
            _context = context;
            _dbSet=context.Set<T>();
        }

        //This method will return all the Records from the table
        public async Task<IEnumerable<T>> GetAllAsync()
        {
            return await _dbSet.ToListAsync();
        }

        //This method will return the specified record from the table
        //based on the Id which it received as an argument
        public async Task<T?> GetByIdAsync(object Id)
        {
            return await _dbSet.FindAsync(Id);
        }

        //This method will Insert one object into the table
        //It will receive the object as an argument which needs to be inserted into the database
        public async Task InsertAsync(T Entity)
        {
            await _dbSet.AddAsync(Entity);
        }

        //This method is going to update the record in the table
        //It will receive the object as an argument
        public async Task UpdateAsync(T Entity)
        {
            _dbSet.Update(Entity);
        }

        //This method is going to remove the record from the table
        //It will receive the primary key value as an argument whose information needs to be removed from the table
        public async Task DeleteAsync(object Id)
        {
            var entity = await _dbSet.FindAsync(Id);
            if(entity != null)
            {
                _dbSet.Remove(entity);
            }
        }

        //SaveChanges for Insert, Update, Delete
        public async Task SaveAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}

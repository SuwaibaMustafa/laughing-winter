﻿using CRUD_OPERATIONS.Interfaces;
using CRUD_OPERATIONS.Models;
using CRUD_OPERATIONS.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography.X509Certificates;

namespace CRUD_OPERATIONS
{
    public class Startup
    {
        private readonly IConfiguration _configuration;
        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRazorPages();
            services.AddDbContext<EmployeeDBContext>(options =>
            {
                options.UseSqlServer(_configuration.GetConnectionString("EFCoreDBConnection"));
            });
            services.AddMvc(options =>
            {
                options.Filters.Add(new ResponseCacheAttribute
                {
                    Location = ResponseCacheLocation.None,
                    NoStore = true
                });
            });
            services.AddControllersWithViews();
            services.AddSession();

            //Non-Generic Repository
            services.AddScoped<IEmployeeRepository, EmployeeRepository>();
            //Generic Repository
            services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));

        }
        public void Configure(WebApplication app, IWebHostEnvironment env)
        {
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseAuthorization();
            app.UseSession();
            app.MapRazorPages();
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Account}/{action=Login}/{id?}");
            app.Use(async (context, next) =>
            {
                await next();

                // If there's no response yet (404) and no specific route is hit
                if (context.Response.StatusCode == 404 && !context.Response.HasStarted)
                {
                    context.Response.Redirect("/Error/PageNotFound"); // Redirect to the default page
                }
            });
            app.Run();

        }
    }
}
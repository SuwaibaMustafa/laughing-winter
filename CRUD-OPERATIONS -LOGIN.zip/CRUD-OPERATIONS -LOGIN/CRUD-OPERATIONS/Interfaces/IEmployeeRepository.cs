﻿using CRUD_OPERATIONS.Models;

namespace CRUD_OPERATIONS.Interfaces
{
    public interface IEmployeeRepository : IGenericRepository<Employee>
    {
        //List
        Task<IEnumerable<Employee>> GetAllEmployeesAsync();

        //Details
        Task<Employee?> GetEmployeeByIdAsync(int EmployeeID);


        //This method will return Employees by Departmentid
        Task<IEnumerable<Employee>> GetEmployeesByDepartmentAsync(int Departmentid);


        ////Create
        //Task InsertAsync(Employee employee);

        ////Edit
        //Task UpdateAsync(Employee employee);

        ////Delete
        //Task DeleteAsync(int employeeId);

        ////Save Changes
        //Task SaveAsync();
    }
}

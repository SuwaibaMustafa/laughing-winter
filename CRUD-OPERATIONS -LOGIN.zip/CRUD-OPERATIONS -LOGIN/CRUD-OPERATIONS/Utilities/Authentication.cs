﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;

namespace CRUD_OPERATIONS.Utilities
{
 
    public class UserAuthentication : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var userName = filterContext.HttpContext.Session.GetString("UserName");
            var role = filterContext.HttpContext.Session.GetString("Role");

            if (userName == null || role != "user")
            {
                filterContext.Result = new RedirectToRouteResult(
                    new RouteValueDictionary {
                        { "Controller", "Employees" },
                        { "Action", "Index" }
                    });
            }
        }
    }

    public class AdminAuthentication : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var userName = filterContext.HttpContext.Session.GetString("UserName");
            var role = filterContext.HttpContext.Session.GetString("Role");

            if (userName == null || role != "admin")
            {
                filterContext.Result = new RedirectToRouteResult(
                    new RouteValueDictionary {
                        { "Controller", "Departments" },
                        { "Action", "Index" }
                    });
            }
        }
    }
}
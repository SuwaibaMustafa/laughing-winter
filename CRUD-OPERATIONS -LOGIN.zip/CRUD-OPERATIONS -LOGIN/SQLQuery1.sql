CREATE DATABASE EmployeeDB;

USE EmployeeDB;

drop table if exists Users

CREATE TABLE Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    UserName VARCHAR(50) NOT NULL,
    UserPassword VARCHAR(50) NOT NULL,
    Role VARCHAR(50) DEFAULT 'admin' NOT NULL
);

INSERT INTO Users(UserName, UserPassword, Role)
VALUES ('admin', 'admin@123', 'admin'),
		('suwaiba', 'suwaiba@123', 'user');




SELECT * From Users;
SELECT * From Employees;
SELECT * From Departments;

ALTER TABLE Employees
ADD  LoginId INT

ALTER TABLE Employees
ADD CONSTRAINT FK_LoginId
FOREIGN KEY (LoginId)
REFERENCES Users(UserId);

DELETE FROM Users
WHERE UserId=5;
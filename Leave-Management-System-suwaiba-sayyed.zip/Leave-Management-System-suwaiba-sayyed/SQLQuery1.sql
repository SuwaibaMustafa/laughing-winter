--DATABASE CREATION
CREATE	DATABASE	Company;

--USE
USE	Company;
drop table if exists EmployeeDetails;

-- Create the EmployeeDetails table
CREATE TABLE EmployeeDetails (
    EmployeeId    INT PRIMARY KEY IDENTITY(1,1),
    EmployeeName  VARCHAR(255),
    Contact	      VARCHAR(30),
	Department	  VARCHAR(50),
	Age			  INT,
	Gender		  VARCHAR(30),
	Salary		  INT
);

-- Insert data into the EmployeeDetails table
INSERT INTO EmployeeDetails (EmployeeName, Contact, Department, Age, Gender, Salary)
VALUES
    ('Mustafa Shaikh', 9874521045, 'HR', 21,'Male', 90000),
    ('Suwaiba Sayyed', 8521401236, 'Finance', 21,'Female', 60000),
    ('Harshada Barve', 9874563210, 'IT', 28,'Female', 55000),
	('Ujjwal Jejurkar', 7412580265, 'Marketing', 30,'Male', 50000),
    ('Danish Sayyed', 8454415201, 'Sales', 35,'Male', 60000),
	('Krutika Rawal', 7854120369, 'Operations', 40,'Female', 50000),
    ('Kainat Sayyed', 9876543210, 'Customer Service', 35,'Female', 30000),
	('Salman Khan', 9874563210, 'Research and Development', 40,'Male', 50000),
    ('Pateek Nayak', 9874563222, 'Accounting', 35,'Male', 60000),
	('Danish Khan', 7854120365, 'Administration', 30,'Male', 10000),
    ('Aliya Khan', 9874563210, 'Production', 35,'Female', 60000),
	('Priya Kapoor', 9512365748, 'Quality Assurance', 30,'Female', 50000),
    ('Omkar Chatterjee',7453698521, 'Supply Chain', 35,'Male', 60000),
    ('Karan Kundra', 7542220365, 'Design', 28,'Male', 55000),
    ('Tejaswi Prakash', 7452103658, 'Public Relations', 28,'Female', 55000),
    ('Abhishekh Sharma', 8521475210, 'Healthcare', 28,'Male', 55000),
    ('Swaroop Thole',78541203658, 'Education', 22,'Male', 55000),
    ('Raj Aryan', 9637531598, 'Non-profit', 28,'Male', 55000),
	('Krishna Jadhav',9874563210, 'Production', 41,'Male', 55000),
    ('Pratik Gosavi',7896541230, 'Management', 28,'Male', 55000),
    ('Jagruti Dahivadkar',7895621036, 'HR', 39,'Female', 55000),
    ('Prince Karavadiya', 8745963210, 'Quality Assurance', 28,'Male', 55000),
    ('Mayank Gupta',8521021457, 'Sales', 28,'Male', 55000),
	('Rahul Bathija',9874563215, 'Production', 28,'Male', 55000),
    ('Dayanvi Anand', 7854236999, 'IT', 34,'Female', 55000),
    ('Mehraj Khan', 89800000025, 'Administration', 28,'Male', 55000),
    ('Roshni Sethe', 8521479630, 'IT', 28,'Female', 55000),
    ('Mustaquim Sayyed',9750351850, 'IT', 33,'Male', 55000);


Select * From EmployeeDetails;

-- Create the LeaveTypes table
CREATE TABLE LeaveTypes (
    LeaveTypeId		INT PRIMARY KEY IDENTITY(1,1),
    TypeName		VARCHAR(255)
);

-- Insert data into the LeaveTypes table
INSERT INTO LeaveTypes (TypeName)
VALUES
    ('Privilege Leave (PL)'),
    ('Casual Leave (CL)'),
    ('Sick Leave (SL)'),
    ('Maternity Leave (ML)'),
    ('Compensatory Off (Comp-off)'),
    ('Marriage Leave'),
	('Paternity Leave'),
    ('Bereavement Leave'),
    ('Unpaid Leave'),
	('Short Leave'),
	('Half Day');

SELECT * FROM LeaveTypes;

-- Create the Leaves table
CREATE TABLE LeaveApplication (
    LeaveId			INT PRIMARY KEY IDENTITY(1,1),
    EmployeeId		INT,
    LeaveTypeId		INT,
    LeaveReason		VARCHAR(MAX),
    LeaveDate		DATE,
    LeaveStatus		VARCHAR(30), --  Pending, Approved,  Rejected, Canceled
    FOREIGN KEY (EmployeeId) REFERENCES EmployeeDetails(EmployeeId),
    FOREIGN KEY (LeaveTypeId) REFERENCES LeaveTypes(LeaveTypeId)
);

-- Insert data into the Leaves table 
INSERT INTO LeaveApplication(EmployeeId, LeaveTypeId, LeaveReason, LeaveDate, LeaveStatus)
VALUES
    (1, 1, 'Vacation request', '2023-11-15', 'Pending'),
    (2, 2, 'Sick leave request', '2023-11-16', 'Approved'),
    (3, 1, 'Vacation request', '2023-11-17', 'Rejected'),
    (4, 3, 'Maternity leave request', '2023-11-18', 'Canceled');


SELECT	*
FROM	LeaveApplication;

drop table if exists UserCredentials;

CREATE TABLE UserCredentials (
    UserId INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50) NOT NULL,
    Password NVARCHAR(50) NOT NULL,
	Role	 VARCHAR(30) DEFAULT 'user'
);

INSERT INTO UserCredentials (Username, Password, Role) VALUES ('Admin', 'Admin@123','admin');

SELECT * FROM UserCredentials










﻿using System.Web;
using System.Web.Mvc;

namespace Leave_Management_System_suwaiba_sayyed
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}

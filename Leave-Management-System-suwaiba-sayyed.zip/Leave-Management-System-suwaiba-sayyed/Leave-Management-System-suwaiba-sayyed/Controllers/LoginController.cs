﻿using Leave_Management_System_suwaiba_sayyed.Models;
using System.Linq;
using System.Web.Mvc;
using System.Web.Security;

namespace Leave_Management_System_suwaiba_sayyed.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            if (User.Identity.IsAuthenticated)
            {
                // User is already logged in, redirect to the home page or another page
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        [HttpPost]
        [ActionName("Index")]
        public ActionResult Login(UserCredential user)
        {
            if (ModelState.IsValid)
            {
                CompanyEntities1 db = new CompanyEntities1();
                var credentials = db.UserCredentials
                    .Where(x => x.Username.ToLower() == user.Username.ToLower() && x.Password == user.Password)
                    .FirstOrDefault();

                if (credentials != null)
                {
                    Session["UserId"] = credentials.UserId;
                    Session["Username"] = credentials.Username;
                    FormsAuthentication.SetAuthCookie(user.Username.ToLower(), false);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    Session["UserId"] = null;
                    Session["Username"] = null;
                    Session.Abandon();
                    ViewBag.ErrorMessage = "Invalid Username or password";
                    return View();
                }
            }
            return View();
        }

        [HttpGet]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session["UserId"] = null;
            Session["Username"] = null;
            Session.Abandon();
            return View("Index");
        }

        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(UserCredential user)
        {
            if (ModelState.IsValid)
            {
                CompanyEntities1 db = new CompanyEntities1();
                // Check if the username is already in use
                if (db.UserCredentials.Any(x => x.Username.ToLower() == user.Username.ToLower()))
                {
                    ModelState.AddModelError("Username", "Username already in use.");
                    return View(user);
                }

                // Add the new user to the database
                db.UserCredentials.Add(user);
                db.SaveChanges();

                // Redirect to the login page after successful registration
                return RedirectToAction("Index");
            }
            return View(user); // Return to the registration form with validation errors
        }
    }
}

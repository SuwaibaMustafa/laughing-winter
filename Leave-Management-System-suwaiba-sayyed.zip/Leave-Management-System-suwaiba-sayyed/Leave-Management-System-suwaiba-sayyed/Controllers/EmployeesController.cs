﻿using Leave_Management_System_suwaiba_sayyed.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace Leave_Management_System_suwaiba_sayyed.Controllers
{
    public class EmployeesController : Controller
    {
        private CompanyEntities1 EmployeesDBContext = new CompanyEntities1();

        // GET: Employees/ListEmployees
        public ActionResult ListEmployees()
        {
            List<EmployeeDetail> employeeList = EmployeesDBContext.EmployeeDetails.ToList();
            return View(employeeList);
        }

        // GET: Employees/CreateEmployees
        public ActionResult CreateEmployees()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateEmployees(EmployeeDetail model)
        {
            if (ModelState.IsValid)
            {
                EmployeesDBContext.EmployeeDetails.Add(model);
                EmployeesDBContext.SaveChanges();
                return RedirectToAction("ListEmployees");
            }
            return View(model);
        }

        // GET: Employees/EditEmployees/5
        public ActionResult EditEmployees(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            EmployeeDetail employee = EmployeesDBContext.EmployeeDetails.Find(id);

            if (employee == null)
            {
                return HttpNotFound();
            }

            return View(employee);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditEmployees(EmployeeDetail model)
        {
            if (ModelState.IsValid)
            {
                EmployeesDBContext.Entry(model).State = EntityState.Modified;
                EmployeesDBContext.SaveChanges();
                return RedirectToAction("ListEmployees");
            }
            return View(model);
        }

        // GET: Employees/DeleteEmployees/5
        public ActionResult DeleteEmployees(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            EmployeeDetail employee = EmployeesDBContext.EmployeeDetails.Find(id);

            if (employee == null)
            {
                return HttpNotFound();
            }

            return View(employee);
        }

        [HttpPost, ActionName("DeleteEmployees")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteEmployeesConfirmed(int id)
        {
            EmployeeDetail employee = EmployeesDBContext.EmployeeDetails.Find(id);
            EmployeesDBContext.EmployeeDetails.Remove(employee);
            EmployeesDBContext.SaveChanges();
            return RedirectToAction("ListEmployees");
        }

        // GET: Employees/DetailsEmployees/5
        public ActionResult DetailsEmployees(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            EmployeeDetail employee = EmployeesDBContext.EmployeeDetails.Find(id);

            if (employee == null)
            {
                return HttpNotFound();
            }

            return View(employee);
        }
    }
}

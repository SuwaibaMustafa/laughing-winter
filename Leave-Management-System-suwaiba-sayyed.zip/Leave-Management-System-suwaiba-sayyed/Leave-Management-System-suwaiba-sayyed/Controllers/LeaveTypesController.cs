﻿using Leave_Management_System_suwaiba_sayyed.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Leave_Management_System_suwaiba_sayyed.Controllers
{
    public class LeaveTypesController : Controller
    {
        // GET: LeaveTypes
        public ActionResult ListLeaveTypes()
        {
            CompanyEntities1 LeaveTypesDBContext = new CompanyEntities1();
            List<LeaveType>  leaveTypesList= LeaveTypesDBContext.LeaveTypes.ToList();
            return View(leaveTypesList);
        }
    }
}
﻿using Leave_Management_System_suwaiba_sayyed.Filters;
using Leave_Management_System_suwaiba_sayyed.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace Leave_Management_System_suwaiba_sayyed.Controllers
{
    [CustomAuthorizationFilter]
    public class UserController : Controller
    {

        public ActionResult Index()
        {
            return View();
        }
    }
}
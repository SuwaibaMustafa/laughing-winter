﻿using Leave_Management_System_suwaiba_sayyed.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace Leave_Management_System_suwaiba_sayyed.Controllers
    {
        public class AdminLoginController : Controller
        {
            public ActionResult AdminLogin()
            {
                return View();
            }

            [HttpPost]
            [ActionName("AdminLogin")]
            public ActionResult Login(UserCredential user)
            {
                if (ModelState.IsValid)
                {
                    CompanyEntities db = new CompanyEntities();
                    var credentials = db.UserCredentials
                        .Where(x => x.Username.ToLower() == user.Username.ToLower() && x.Password == user.Password)
                        .FirstOrDefault();

                    if (credentials != null)
                    {
                        // Check if the user has the "admin" role.
                        if (credentials.Role == "admin")
                        {
                            Session["UserId"] = credentials.UserId;
                            Session["Username"] = credentials.Username;
                            FormsAuthentication.SetAuthCookie(user.Username.ToLower(), false);
                            return RedirectToAction("Index", "Home"); // Redirect to the admin dashboard
                        }
                        else
                        {
                            ViewBag.ErrorMessage = "Invalid username or password";
                            return RedirectToAction("Login", "Login");
                        }
                    }
                    else
                    {
                        Session["UserId"] = null;
                        Session["Username"] = null;
                        Session.Abandon();
                        ViewBag.ErrorMessage = "Invalid username or password";
                    }
                }
                return View();
            }
        }
    }



    // GET: AdminLogin
    //public ActionResult AdminLogin()
    //{
    //    return View();
    //}

    //[HttpPost]
    //[ActionName("AdminLogin")]
    //public ActionResult Login(UserCredential user)
    //{
    //    if(ModelState.IsValid)
    //    {
    //        CompanyEntities db=new CompanyEntities();
    //        var credentials = db.UserCredentials.Where(x => x.Username.ToLower() == user.Username.ToLower() && x.Password == user.Password).FirstOrDefault();
    //        if (credentials != null)
    //        {
    //            Session["UserId"]= credentials.UserId;
    //            Session["Username"] = credentials.Username;
    //            FormsAuthentication.SetAuthCookie(user.Username.ToLower(), false);
    //            return RedirectToAction("Index", "Home");          //LeaveApplication Controller
    //        }
    //        else
    //        {
    //            Session["UserId"] = null;
    //            Session["Username"]= null;
    //            Session.Abandon();
    //            ViewBag.ErrorMessage = "Invalid username or password";
    //            return View();
    //        }
    //    }
    //    return View();
    //}


//**********************************************************************************************************

//        [HttpPost]
//        [ActionName("AdminLogin")]
//        public ActionResult Login(AdminUser user)
//        {
//            if (ModelState.IsValid)
//            {
//                ECommerceDBEntities db = new ECommerceDBEntities();
//                var credentials = db.AdminUsers.Where(x => x.Username.ToLower() == user.Username.ToLower() &&
//                                                        x.Password == user.Password).FirstOrDefault();

//                if (credentials != null)
//                {
//                    Session["UserId"] = credentials.AdminID;
//                    Session["Username"] = credentials.Username;
//                    FormsAuthentication.SetAuthCookie(user.Username.ToLower(), false);
//                    return RedirectToAction("Index", "AdminHandlingUserOrders");
//                }
//                else
//                {
//                    Session["UserId"] = null;
//                    Session["Username"] = null;
//                    Session.Abandon();
//                    ViewBag.ErrorMessage = "Invalid Username or password";
//                    return View();
//                }
//            }
//            return View();
//        }
//    }
//}
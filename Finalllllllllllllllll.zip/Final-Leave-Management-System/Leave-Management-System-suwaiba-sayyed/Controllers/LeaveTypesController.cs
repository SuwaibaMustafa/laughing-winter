﻿using Leave_Management_System_suwaiba_sayyed.Filters;
using Leave_Management_System_suwaiba_sayyed.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Leave_Management_System_suwaiba_sayyed.Controllers
{
    [CustomAuthorizationFilter]
    public class LeaveTypesController : Controller
    {
        // GET: LeaveTypes
        public ActionResult ListLeaveTypes()
        {
            CompanyEntities LeaveTypesDBContext = new CompanyEntities();
            List<LeaveType> leaveTypesList = LeaveTypesDBContext.LeaveTypes.ToList();
            return View(leaveTypesList);
        }
    }
}
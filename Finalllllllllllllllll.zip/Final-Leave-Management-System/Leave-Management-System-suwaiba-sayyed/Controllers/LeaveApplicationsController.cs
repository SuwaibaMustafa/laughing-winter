﻿using Leave_Management_System_suwaiba_sayyed.Filters;
using Leave_Management_System_suwaiba_sayyed.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace Leave_Management_System_suwaiba_sayyed.Controllers
{
    [CustomAuthorizationFilter]
    public class LeaveApplicationsController : Controller

    {
        private CompanyEntities LeaveApplicationDBContext = new CompanyEntities();
        // GET: LeaveApplications
        public ActionResult List()
        {
            List<LeaveApplication> leaveApplicationList = LeaveApplicationDBContext.LeaveApplications.ToList();
            return View(leaveApplicationList);
        }


        //public ActionResult Create()
        //{
        //    // Provide data for dropdown lists (e.g., leave types, employees) to the view
        //    ViewBag.LeaveTypes = new SelectList(LeaveApplicationDBContext.LeaveTypes, "LeaveTypeId", "TypeName");
        //    ViewBag.Employees = new SelectList(LeaveApplicationDBContext.EmployeeDetails, "EmployeeId", "EmployeeName");

        //    return View();
        //}

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create(LeaveApplication model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        // Save the new leave application to the database
        //        LeaveApplicationDBContext.LeaveApplications.Add(model);
        //        LeaveApplicationDBContext.SaveChanges();

        //        return RedirectToAction("List");
        //    }

        //    // If validation fails, return to the creation form with validation errors
        //    ViewBag.LeaveTypes = new SelectList(LeaveApplicationDBContext.LeaveTypes, "LeaveTypeId", "TypeName");
        //    ViewBag.Employees = new SelectList(LeaveApplicationDBContext.EmployeeDetails, "EmployeeId", "EmployeeName");
        //    return View(model);
        //}


        // GET: LeaveApplications/Edit/5
        //public ActionResult Edit(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }

        //    LeaveApplication leaveApplication = LeaveApplicationDBContext.LeaveApplications.Find(id);

        //    if (leaveApplication == null)
        //    {
        //        return HttpNotFound();
        //    }

        //    // Provide data for dropdown lists (e.g., leave types, employees) to the view
        //    ViewBag.LeaveTypes = new SelectList(LeaveApplicationDBContext.LeaveTypes, "LeaveTypeId", "TypeName");
        //    ViewBag.Employees = new SelectList(LeaveApplicationDBContext.EmployeeDetails, "EmployeeId", "EmployeeName");

        //    return View(leaveApplication);
        //}
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var data = LeaveApplicationDBContext.LeaveApplications.Find(id);

            // Check if the leave date is in the past
            if (data.LeaveDate < DateTime.Today)
            {
                // Leave date is in the past, handle accordingly (e.g., show an error message)
                TempData["ErrorMessage"] = "Cannot perform action on past leave records.";
                return RedirectToAction("List");
            }

            if (data != null)
            {
                ViewBag.LeaveTypes = new SelectList(LeaveApplicationDBContext.LeaveTypes, "LeaveTypeId", "TypeName");
                ViewBag.Employees = new SelectList(LeaveApplicationDBContext.EmployeeDetails, "EmployeeId", "EmployeeName");
                return View(data);
            }
            else
            {
                return HttpNotFound();
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(LeaveApplication model)
        {
            // Check if the leave date is in the past
            if (model.LeaveDate < DateTime.Today)
            {
                // Leave date is in the past, handle accordingly (e.g., show an error message)
                TempData["ErrorMessage"] = "Cannot perform action on past leave records.";
                return RedirectToAction("List");
            }

            if (ModelState.IsValid)
            {
                LeaveApplicationDBContext.Entry(model).State = EntityState.Modified;
                LeaveApplicationDBContext.SaveChanges();
                return RedirectToAction("List");
            }

            ViewBag.LeaveTypes = new SelectList(LeaveApplicationDBContext.LeaveTypes, "LeaveTypeId", "TypeName");
            ViewBag.Employees = new SelectList(LeaveApplicationDBContext.EmployeeDetails, "EmployeeId", "EmployeeName");

            return View(model);
        }

        // GET: Booking/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            LeaveApplication leaveApplication = LeaveApplicationDBContext.LeaveApplications.Find(id);
            if (leaveApplication == null)
            {
                return HttpNotFound();
            }
            return View(leaveApplication);
        }

        // POST: Booking/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            LeaveApplication leaveApplication =LeaveApplicationDBContext.LeaveApplications.Find(id);
            LeaveApplicationDBContext.LeaveApplications.Remove(leaveApplication);
            LeaveApplicationDBContext.SaveChanges();
            return RedirectToAction("List");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                LeaveApplicationDBContext.Dispose();
            }
            base.Dispose(disposing);
        }
    }

}

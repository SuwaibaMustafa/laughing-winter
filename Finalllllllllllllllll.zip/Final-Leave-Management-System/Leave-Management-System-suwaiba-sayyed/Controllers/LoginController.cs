﻿using Leave_Management_System_suwaiba_sayyed.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace Leave_Management_System_suwaiba_sayyed.Controllers
{
    public class LoginController : Controller
    {
        private CompanyEntities _dbContext;
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ActionName("Login")]
        public ActionResult Login (UserCredential user)
        {
            if(ModelState.IsValid)
            {
                CompanyEntities db= new CompanyEntities();
                var credentials= db.UserCredentials.Where(x => x.Username.ToLower() == user.Username.ToLower() && x.Password == user.Password).FirstOrDefault();
                if(credentials != null)
                {
                    Session["UserId"] = credentials.UserId;
                    Session["Username"] = credentials.Username;
                    FormsAuthentication.SetAuthCookie(user.Username.ToLower(), false);
                    return RedirectToAction("Index", "User");
                }
                else
                {
                    Session["UserId"] = null;
                    Session["Username"]= null;
                    Session.Abandon();
                    ViewBag.ErrorMessage = "Invalid Username or Password";
                    return View();

                }
            }
            return View();
        }
        private void CreateAuthenticationEntry (int userId)
        {
            // Logic to create an entry in the Authentication table for the specified user ID
            // This method should interact with your database context to create the authentication entry
            // For example, using Entity Framework:

            // Assuming you have an instance of your database context named _dbContext

            // Check if an entry for the user already exists in the AuthenticatedUsers table
            var existingEntry = _dbContext.UserCredentials.FirstOrDefault(u => u.UserId == userId);
            // If an entry doesn't exist, create a new one
            if (existingEntry == null) 
            {
                var authenticationEntry = new UserCredential
                {
                    UserId = userId,
                    Username = "",
                    Password = ""

                };

                // Add the new authentication entry to the AuthenticatedUsers table
                _dbContext.UserCredentials.Add(authenticationEntry);

                //                // Save changes to the database
                _dbContext.SaveChanges();
            }

        }
    }
}



﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using Leave_Management_System_suwaiba_sayyed.Models;

namespace Leave_Management_System_suwaiba_sayyed.Controllers
{
    public class RegisterController : Controller
    {
        // GET: Register
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(UserCredential model)
        {
            CompanyEntities db=new CompanyEntities();
            if(ModelState.IsValid)
            {
                try
                {
                    // Create a new RegisteredUser record in the UserCredential table
                    UserCredential newRegisteredUser = new UserCredential
                    {
                        UserId = model.UserId,
                        Username = model.Username,
                        Password = model.Password
,
                    };
                    // Save the new RegisteredUser to the data;base
                    db.UserCredentials.Add(newRegisteredUser);
                    db.SaveChanges();

                    // Create a new AuthenticatedUser record in the AuthenticatedUser table
                    UserCredential newUserCredential = new UserCredential
                    {
                        UserId = newRegisteredUser.UserId,
                        Username = newRegisteredUser.Username,
                        Password = newRegisteredUser.Password
                    };

                    // Save the new AuthenticatedUser to the database 
                    db.UserCredentials.Add(newUserCredential);
                    db.SaveChanges();

                    // Redirect to a success page or login page
                    return RedirectToAction("Login", "Login");
                }
                catch (Exception ex)
                {
                    // Handle database exception and return an error message
                    ModelState.AddModelError(string.Empty, "An error occurred while processing your request. Please try again later.");
                }
            }
            // If registration fails, return to the registration form with errors
            return View(model);
        }
    }
}


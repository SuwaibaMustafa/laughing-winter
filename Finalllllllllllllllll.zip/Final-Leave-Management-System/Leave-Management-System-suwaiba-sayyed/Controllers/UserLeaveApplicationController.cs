﻿using Leave_Management_System_suwaiba_sayyed.Filters;
using Leave_Management_System_suwaiba_sayyed.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace Leave_Management_System_suwaiba_sayyed.Controllers
{
    [CustomAuthorizationFilter]
    public class UserLeaveApplicationController : Controller
    {
        // GET: UserLeaveApplication
        private CompanyEntities LeaveApplicationDBContext = new CompanyEntities();
        // GET: LeaveApplications
        public ActionResult List()
        {
            List<LeaveApplication> leaveApplicationList = LeaveApplicationDBContext.LeaveApplications.ToList();
            return View(leaveApplicationList);
        }


        public ActionResult Create()
        {
            
            // Provide data for dropdown lists (e.g., leave types, employees) to the view
            ViewBag.LeaveTypes = new SelectList(LeaveApplicationDBContext.LeaveTypes, "LeaveTypeId", "TypeName");
            ViewBag.Employees = new SelectList(LeaveApplicationDBContext.EmployeeDetails, "EmployeeId", "EmployeeName");

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(LeaveApplication model)
        {
              if (ModelState.IsValid)
            {
                // Save the new leave application to the database
                LeaveApplicationDBContext.LeaveApplications.Add(model);
                LeaveApplicationDBContext.SaveChanges();

                return RedirectToAction("List");
            }

            // If validation fails, return to the creation form with validation errors
            ViewBag.LeaveTypes = new SelectList(LeaveApplicationDBContext.LeaveTypes, "LeaveTypeId", "TypeName");
            ViewBag.Employees = new SelectList(LeaveApplicationDBContext.EmployeeDetails, "EmployeeId", "EmployeeName");
            return View(model);
        }


        ////    //DELETE
        //// GET: LeaveApplications/Delete/5
        //public ActionResult Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }

        //    LeaveApplication leaveApplication = LeaveApplicationDBContext.LeaveApplications.Find(id);

        //    if (leaveApplication == null)
        //    {
        //        return HttpNotFound();
        //    }

        //    return View(leaveApplication);
        //}

        //// POST: LeaveApplications/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(int id)
        //{
        //    LeaveApplication leaveApplication = LeaveApplicationDBContext.LeaveApplications.Find(id);

        //    if (leaveApplication != null)
        //    {
        //        LeaveApplicationDBContext.LeaveApplications.Remove(leaveApplication);
        //        LeaveApplicationDBContext.SaveChanges();
        //    }

        //    return RedirectToAction("List");
        //}
        //    //DETAILS
        public ActionResult Details(int id)
        {
            CompanyEntities LeaveApplicationDBContext = new CompanyEntities();
            LeaveApplication leaveApplication = LeaveApplicationDBContext.LeaveApplications.Find(id);

            if (leaveApplication == null)
            {
                return HttpNotFound();
            }

            return View(leaveApplication);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Leave_Management_System_suwaiba_sayyed.Filters
{
    public class CustomAuthorizationFilter : ActionFilterAttribute, IActionFilter
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var session = filterContext.HttpContext.Session;
            if (session == null || (session != null && session["Username"] == null))
            {
                filterContext.Result = new RedirectToRouteResult(
                            new RouteValueDictionary { { "controller", "Login" }, { "action", "Login" } });
            }
            base.OnActionExecuting(filterContext);
        }

    }
}